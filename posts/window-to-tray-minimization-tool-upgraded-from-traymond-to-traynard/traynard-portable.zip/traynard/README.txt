Traynard is a Windows desktop utility for minimizing any application window to the system tray, A.K.A. "notification area".

Homepage: https://github.com/tabris17/traynard

Usage:

1. Extract the package to any location on your computer.
2. Run traynard.exe to start the application.
3. If the current directory is not writable, please delete the data folder before running.
